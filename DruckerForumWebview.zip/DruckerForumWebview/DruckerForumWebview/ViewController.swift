//
//  ViewController.swift
//  DruckerForumWebview
//
//  Created by Shady on 23.06.20.
//  Copyright © 2020 imc. All rights reserved.
//

import UIKit
import WebKit

class ViewController: UIViewController {

    @IBOutlet var webview: WKWebView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        webview.load(URLRequest(url: URL(string: "https://www.druckerforum.org")!))
    }
    
}

